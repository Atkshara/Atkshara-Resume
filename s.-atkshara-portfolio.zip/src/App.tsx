/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Certifications from './components/Certifications';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ResumeModal from './components/ResumeModal';

export default function App() {
  const [isResumeOpen, setIsResumeOpen] = useState(false);

  const handleOpenResume = () => {
    setIsResumeOpen(true);
  };

  const handleCloseResume = () => {
    setIsResumeOpen(false);
  };

  const handleViewProjects = () => {
    const projectsSection = document.getElementById('projects');
    if (projectsSection) {
      projectsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-surface text-on-surface">
      {/* Interactive Sticky Top Navbar */}
      <Navbar onResumeClick={handleOpenResume} />

      {/* Main Single-View Segmented Blocks */}
      <main className="w-full">
        <Hero 
          onResumeClick={handleOpenResume} 
          onViewProjectsClick={handleViewProjects} 
        />
        <About />
        <Skills />
        <Projects />
        <Certifications />
        <Contact />
      </main>

      {/* Footnote Branding */}
      <Footer />

      {/* Interactive CV Drawer Overlay */}
      {isResumeOpen && (
        <ResumeModal onClose={handleCloseResume} />
      )}
    </div>
  );
}

