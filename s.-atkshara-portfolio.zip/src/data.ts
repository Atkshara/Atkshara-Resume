import { Project, SkillCategory, Certification } from './types';

export const PROJECTS: Project[] = [
  {
    id: 'voltis',
    title: 'VOLTIS',
    description: 'A comprehensive EV charging platform designed for intelligent power distribution and real-time station monitoring. Built to bridge the gap between infrastructure and end-users.',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD8joBrUCpVtiPhLNBXbG6nUBuuUQH3j6CHHLZic4Mt2wZyVTMmCifPQwn5g27s4l7kPotgNzw2HwJMsrOaAbG9zm_e_J-eEeRYQVuWRqbAv4Jf3v_tdcG_W52HqwQhyFQvDh9CEC3FU9rinqgZKQBoGJLN5_N6hwc1-cb7gVEne--cdM2pXfxfZW4it4gbD7KUI5VF37ZJIkJCfzAM8LFNmnAcrWVEramhSIWPM2DeGCH1q13_sck7T4w1ChMyg2IIplnKiSwjEmUU',
    tag: 'MERN STACK',
    technologies: ['React', 'Node.js', 'MongoDB', 'Express', 'Tailwind'],
    viewLink: '#',
    githubLink: '#',
    details: {
      overview: 'VOLTIS is an enterprise-grade smart charging management platform that balances grid loads dynamically while offering users an intuitive station reservation, live navigation guidance, and flexible mobile payment. It features real-time socket health telemetry and automated failure reporting.',
      keyFeatures: [
        'Dynamic Load Balancing algorithm adjusting supply based on grid load',
        'Interactive map showing near-zero-latency station occupancy state',
        'Automatic billing, receipt generation, and session logs persistence',
        'Developer-friendly analytics dashboard displaying charger health, energy draw, and peak hours analysis'
      ],
      role: 'Lead Full-Stack Developer & Architect',
      timeline: 'Oct 2023 - Jan 2024'
    }
  },
  {
    id: 'arkalegal',
    title: 'ARKALEGAL',
    description: 'A secure legal-tech solution focusing on document automation and case lifecycle management. Leveraging modern encryption to ensure client confidentiality and process efficiency.',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBmmHUdVgoWU0LWPCXa1lCD176o_omacf80MnN8ys7IUklBpWc8UPEtJB3FnDEYFc7P03tnJBd7r9DnsZGr5qsdd_hk7A8_vkYi8PZ2MQEBMW9ogEFUpFWmROlJOUV_4Jr6L2ItMEGzmbcJ2UKr-wZx0oAfYctrsGPjhN27A7D_vNrsTsdThGWySv0Z9A2KQM3P6Efc-QAQfiAGe4UM09K5LotjHm6i8sOyeQi32C8U2f-BCU74pMwWTp54PqMEqSsD9dwK_LCWGr1E',
    tag: 'BLOCKCHAIN',
    technologies: ['Python', 'React', 'AWS', 'Solidity', 'IPFS'],
    viewLink: '#',
    githubLink: '#',
    details: {
      overview: 'ARKALEGAL implements smart-contract-backed document hashing and decentralized storage networks to provide tamper-proof legal custody, automated NDA enforcement, and multi-signature validation pipelines for legal practitioners.',
      keyFeatures: [
        'Immutable document audit trail on-chain preventing retrospective document tampering',
        'Decentralized encrypted file sharing using IPFS (InterPlanetary File System)',
        'Zero-knowledge proof validation workflow to protect client-attorney privilege',
        'Automated contract clause parsing powered by custom-trained micro-LLM models'
      ],
      role: 'Core AI & Cryptographic Smart Contract Developer',
      timeline: 'Feb 2024 - May 2024'
    }
  }
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: 'Programming',
    iconName: 'terminal',
    skills: ['Python', 'Java', 'C / C++', 'JavaScript']
  },
  {
    title: 'Web Dev',
    iconName: 'language',
    skills: ['React / Node', 'Express', 'HTML5 / CSS3', 'Tailwind']
  },
  {
    title: 'AI & ML',
    iconName: 'psychology',
    skills: ['TensorFlow', 'Keras / Scikit', 'Pandas', 'NumPy']
  },
  {
    title: 'Databases',
    iconName: 'database',
    skills: ['MySQL', 'MongoDB', 'PostgreSQL', 'Redis']
  },
  {
    title: 'Tools',
    iconName: 'construction',
    skills: ['Git / GitHub', 'VS Code', 'Canva', 'Colab']
  }
];

export const CERTIFICATIONS: Certification[] = [
  {
    title: 'NPTEL IoT 4.0',
    description: 'Certified in advanced Industrial IoT systems and smart manufacturing processes.',
    credentialUrl: '#',
    iconName: 'workspace_premium'
  },
  {
    title: 'IoT Internship',
    description: 'Hands-on experience in sensor integration and real-time data streaming architectures.',
    credentialUrl: '#',
    iconName: 'badge'
  },
  {
    title: 'Deloitte Certificate',
    description: 'Professional certification in enterprise-grade software development practices.',
    credentialUrl: '#',
    iconName: 'verified'
  }
];
