export interface Project {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  tag: string;
  technologies: string[];
  viewLink: string;
  githubLink: string;
  details: {
    overview: string;
    keyFeatures: string[];
    role: string;
    timeline: string;
  };
}

export interface SkillCategory {
  title: string;
  iconName: string;
  skills: string[];
}

export interface Certification {
  title: string;
  description: string;
  credentialUrl: string;
  iconName: string;
}
