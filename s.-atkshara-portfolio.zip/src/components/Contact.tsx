import React, { useState } from 'react';
import { Mail, Smartphone, Share2, Link2, Terminal, CheckCircle } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const tempErrors: Record<string, string> = {};
    if (!formData.name.trim()) tempErrors.name = 'Full name is required';
    if (!formData.email.trim()) {
      tempErrors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      tempErrors.email = 'Please provide a valid email';
    }
    if (!formData.message.trim()) tempErrors.message = 'Message content is required';
    
    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    
    // Simulate API delivery
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      // Reset form
      setFormData({ name: '', email: '', message: '' });
    }, 1200);
  };

  return (
    <section 
      id="contact" 
      className="py-section-gap bg-[#F8F5F2] text-inverse-on-surface"
    >
      <div className="max-w-container-max mx-auto px-gutter">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          
          {/* Left Column: Contact info & metadata */}
          <div className="space-y-8 text-left">
            <h2 className="font-display-lg text-display-lg-mobile md:text-5xl lg:text-display-lg text-inverse-on-surface leading-tight font-serif">
              Get In Touch
            </h2>
            <p className="font-body-lg text-on-surface-variant max-w-md leading-relaxed text-[#5F534F]">
              Currently open to internships, freelance projects, and research collaborations. Let's build something remarkable together.
            </p>

            {/* Structured info grids */}
            <div className="space-y-6 pt-4">
              <div className="flex items-center gap-6 group">
                <div className="w-12 h-12 rounded-full border border-primary/40 flex items-center justify-center group-hover:bg-primary group-hover:text-[#191210] group-hover:border-primary transition-all duration-300">
                  <Mail className="w-5 h-5 text-primary group-hover:text-inherit" />
                </div>
                <div>
                  <p className="font-label-caps text-primary text-xs font-semibold tracking-wider">EMAIL ME</p>
                  <a 
                    href="mailto:atkshara.s@example.com"
                    className="font-headline-sm text-lg md:text-xl font-serif text-inverse-on-surface hover:text-primary transition-colors"
                  >
                    atkshara.s@example.com
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-6 group">
                <div className="w-12 h-12 rounded-full border border-primary/40 flex items-center justify-center group-hover:bg-primary group-hover:text-[#191210] group-hover:border-primary transition-all duration-300">
                  <Smartphone className="w-5 h-5 text-primary group-hover:text-inherit" />
                </div>
                <div>
                  <p className="font-label-caps text-primary text-xs font-semibold tracking-wider">CALL ME</p>
                  <a 
                    href="tel:+919876543210"
                    className="font-headline-sm text-lg md:text-xl font-serif text-inverse-on-surface hover:text-primary transition-colors"
                  >
                    +91 98765 43210
                  </a>
                </div>
              </div>
            </div>

            {/* Bottom utility handles */}
            <div className="flex gap-4 pt-8 border-t border-outline-variant/10 w-full max-w-xs">
              <button 
                className="w-10 h-10 border border-inverse-on-surface/15 rounded-full flex items-center justify-center hover:bg-primary hover:text-[#191210] hover:border-primary transition-all duration-300 cursor-pointer"
                title="Share portfolio"
                onClick={() => {
                  navigator.clipboard.writeText(window.location.href);
                  alert('Portfolio link copied to clipboard!');
                }}
              >
                <Share2 className="w-4 h-4" />
              </button>
              
              <a 
                href="#"
                className="w-10 h-10 border border-inverse-on-surface/15 rounded-full flex items-center justify-center hover:bg-primary hover:text-[#191210] hover:border-primary transition-all duration-300"
                title="Portfolio Link"
              >
                <Link2 className="w-4 h-4" />
              </a>

              <a 
                href="#"
                className="w-10 h-10 border border-inverse-on-surface/15 rounded-full flex items-center justify-center hover:bg-primary hover:text-[#191210] hover:border-primary transition-all duration-300"
                title="Workspace"
              >
                <Terminal className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Right Column: Light Glass Input Form */}
          <div className="light-glass p-8 sm:p-12 rounded-3xl shadow-xl relative overflow-hidden text-left border border-outline-variant/10">
            {submitted ? (
              <div className="py-12 text-center space-y-4 animate-scaleIn">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto text-green-600">
                  <CheckCircle className="w-10 h-10" />
                </div>
                <h3 className="font-headline-md font-serif text-2xl text-inverse-on-surface">Message Sent!</h3>
                <p className="text-sm text-on-surface-variant max-w-sm mx-auto leading-relaxed">
                  Thank you for reaching out! S. Atkshara has received your inquiry and will respond as soon as possible.
                </p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="mt-6 px-6 py-2 border border-outline-variant/20 hover:bg-primary hover:text-white rounded-lg text-xs font-bold tracking-widest uppercase transition-all duration-200 cursor-pointer"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Full Name field */}
                <div className="space-y-2">
                  <label className="font-label-caps text-inverse-on-surface font-semibold text-xs tracking-wider">
                    FULL NAME
                  </label>
                  <input 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className={`w-full bg-transparent border-b ${
                      errors.name ? 'border-red-500' : 'border-inverse-on-surface/20'
                    } focus:border-primary focus:ring-0 px-0 py-3 outline-none text-inverse-on-surface placeholder-on-surface-variant/50 text-sm`} 
                    placeholder="John Doe" 
                    type="text"
                  />
                  {errors.name && <p className="text-xs text-red-500 mt-1 font-medium">{errors.name}</p>}
                </div>

                {/* Email address field */}
                <div className="space-y-2">
                  <label className="font-label-caps text-inverse-on-surface font-semibold text-xs tracking-wider">
                    EMAIL ADDRESS
                  </label>
                  <input 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`w-full bg-transparent border-b ${
                      errors.email ? 'border-red-500' : 'border-inverse-on-surface/20'
                    } focus:border-primary focus:ring-0 px-0 py-3 outline-none text-inverse-on-surface placeholder-on-surface-variant/50 text-sm`} 
                    placeholder="john@example.com" 
                    type="email"
                  />
                  {errors.email && <p className="text-xs text-red-500 mt-1 font-medium">{errors.email}</p>}
                </div>

                {/* Message field */}
                <div className="space-y-2">
                  <label className="font-label-caps text-inverse-on-surface font-semibold text-xs tracking-wider">
                    MESSAGE
                  </label>
                  <textarea 
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    className={`w-full bg-transparent border-b ${
                      errors.message ? 'border-red-500' : 'border-inverse-on-surface/20'
                    } focus:border-primary focus:ring-0 px-0 py-3 outline-none resize-none text-inverse-on-surface placeholder-on-surface-variant/50 text-sm`} 
                    placeholder="How can I help you?" 
                    rows={4}
                  />
                  {errors.message && <p className="text-xs text-red-500 mt-1 font-medium">{errors.message}</p>}
                </div>

                {/* Action CTA Button */}
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-5 bg-primary text-on-primary font-label-caps text-label-caps tracking-widest rounded-xl hover:shadow-lg hover:scale-101 active:scale-95 transition-all duration-200 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'SENDING...' : 'SEND MESSAGE'}
                </button>
              </form>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}
