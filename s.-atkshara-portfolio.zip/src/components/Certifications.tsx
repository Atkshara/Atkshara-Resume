import React from 'react';
import { Award, Briefcase, BadgeCheck, ExternalLink } from 'lucide-react';
import { CERTIFICATIONS } from '../data';

const iconMap: Record<string, React.ComponentType<any>> = {
  workspace_premium: Award,
  badge: Briefcase,
  verified: BadgeCheck,
};

export default function Certifications() {
  return (
    <section className="py-section-gap bg-[#2F221E] relative">
      <div className="max-w-container-max mx-auto px-gutter">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-headline-md text-on-surface font-serif text-3xl">
            Recognition &amp; Certifications
          </h2>
          <div className="sandal-divider w-24 mx-auto mt-4" />
        </div>

        {/* Certifications Grid */}
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-8">
          {CERTIFICATIONS.map((cert) => {
            const IconComponent = iconMap[cert.iconName] || Award;
            return (
              <div 
                key={cert.title}
                className="glass p-8 rounded-2xl group cursor-default hover:border-primary/20 hover:-translate-y-1 transition-all duration-300 text-left flex flex-col justify-between"
              >
                <div>
                  {/* Icon Frame */}
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-6 text-primary group-hover:bg-primary group-hover:text-background transition-all duration-300">
                    <IconComponent className="w-6 h-6" />
                  </div>

                  {/* Title & Description */}
                  <h3 className="font-headline-sm mb-2 text-on-surface text-lg font-semibold tracking-tight">
                    {cert.title}
                  </h3>
                  <p className="font-body-md text-on-surface-variant text-sm leading-relaxed mb-6">
                    {cert.description}
                  </p>
                </div>

                {/* Verification Link */}
                <a 
                  href={cert.credentialUrl}
                  className="inline-flex items-center gap-1.5 text-xs font-label-caps text-tertiary hover:text-white tracking-widest transition-colors duration-200"
                >
                  VERIFY CREDENTIAL
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
