import React from 'react';
import { MapPin, Sparkles } from 'lucide-react';

export default function About() {
  return (
    <section 
      id="about" 
      className="py-section-gap bg-[#F8F5F2] text-inverse-on-surface"
    >
      <div className="max-w-container-max mx-auto px-gutter">
        <div className="grid md:grid-cols-2 gap-16 lg:gap-24 items-center">
          
          {/* Left: Interactive Framing Portrait */}
          <div className="relative max-w-md mx-auto md:max-w-none w-full">
            {/* Editorial Corner Borders */}
            <div className="absolute -top-4 -left-4 w-24 h-24 border-t-2 border-l-2 border-primary pointer-events-none" />
            <div className="absolute -bottom-4 -right-4 w-24 h-24 border-b-2 border-r-2 border-tertiary pointer-events-none" />
            
            {/* Portrait Card */}
            <div className="aspect-square overflow-hidden bg-surface-container shadow-2xl grayscale hover:grayscale-0 transition-all duration-700 ease-in-out rounded-lg border border-[#E9E4DE]">
              <img 
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.03]" 
                alt="Portrait of S. Atkshara, AI & Full Stack Software Engineer" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuA4PXoztxKcAED4q0xQKcAfRSft8AC1AFTYmJoT4jNmkZ5jJiF8tJb8dHoA_DU8nJpQZQHf3vZfBoeXq2g_yqlTGKpdZAklHucwBStriMsFYCx8UPmRPMitsRAKgsu76QN9DyQv4lWKw87DuB6ecUEQT1MCF3HsMtnClHmUTYJWFQ2qQ3XP33qJ0dWRwAmWRqvXuIlNaFcFVKhuAGWrjp2rXuXvbIwXgSkV1X7v38NTIi-uFnh0dB69zqkb9UU62LYlxiy_gZrNrJLs"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Right: Editorial Professional Background */}
          <div className="space-y-8 text-left">
            <div className="space-y-4">
              <h2 className="font-display-lg text-display-lg-mobile md:text-5xl lg:text-display-lg text-inverse-on-surface leading-tight font-serif">
                Crafting Intelligence <br />&amp; Interfaces
              </h2>
              <div className="w-20 h-1.5 bg-primary rounded-full" />
            </div>

            <div className="space-y-6 font-body-lg text-body-lg text-on-surface-variant leading-relaxed">
              <p>
                I am a dedicated AI &amp; Machine Learning student with a passion for building full-stack applications that solve real-world problems. My engineering journey is defined by a deep curiosity for data patterns paired with a love for pixel-perfect digital craftsmanship.
              </p>
              <p>
                I thrive at the intersection of complex machine learning algorithms and elegant user-centric systems. Whether it's optimizing electrical vehicle grids or engineering robust document workflow security, I enjoy finding creative solutions where data-backed brains meet beautiful visual portals.
              </p>
            </div>

            {/* Quick Metadata Metadata Details */}
            <div className="grid grid-cols-2 gap-8 pt-6 border-t border-outline-variant/15">
              <div className="flex flex-col">
                <p className="font-label-caps text-tertiary-container font-semibold mb-2 flex items-center gap-1.5 tracking-wider uppercase text-xs">
                  <MapPin className="w-3.5 h-3.5 text-primary" />
                  LOCATION
                </p>
                <p className="font-headline-sm font-medium text-inverse-on-surface">Chennai, India</p>
              </div>
              
              <div className="flex flex-col">
                <p className="font-label-caps text-tertiary-container font-semibold mb-2 flex items-center gap-1.5 tracking-wider uppercase text-xs">
                  <Sparkles className="w-3.5 h-3.5 text-tertiary" />
                  EXPERTISE
                </p>
                <p className="font-headline-sm font-medium text-inverse-on-surface">AI, ML, MERN</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
