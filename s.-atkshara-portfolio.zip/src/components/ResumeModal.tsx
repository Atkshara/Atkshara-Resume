import React from 'react';
import { X, Download, MapPin, Mail, Phone, BookOpen, Briefcase, Award, GraduationCap } from 'lucide-react';

interface ResumeModalProps {
  onClose: () => void;
}

export default function ResumeModal({ onClose }: ResumeModalProps) {
  const handleDownload = () => {
    // Generate a simple text file download representation of the resume
    const resumeText = `
S. ATKSHARA
AI & Machine Learning Undergraduate & Full Stack Developer
Email: atkshara.s@example.com | Phone: +91 98765 43210
Location: Chennai, India

EDUCATION
--------------------------------------------------
B.Tech in Artificial Intelligence & Machine Learning
CGPA: 9.4/10 | Expected Graduation: 2025

TECHNICAL ACUMEN
--------------------------------------------------
* Programming: Python, Java, C/C++, JavaScript
* Web Development: React, Node.js, Express, HTML5/CSS3, Tailwind CSS
* AI & ML: TensorFlow, Keras, Scikit-learn, Pandas, NumPy
* Databases: MySQL, MongoDB, PostgreSQL, Redis
* Tools: Git, GitHub, VS Code, Canva, Google Colab

PROFESSIONAL EXPERIENCE
--------------------------------------------------
IoT Research Intern
* Developed sensor integration pipelines for real-time telemetry streaming
* Optimized data streaming speeds and dashboard telemetry visuals
* Integrated IoT edge sensors with backend database brokers

ACCOMPLISHMENTS & CERTIFICATIONS
--------------------------------------------------
* NPTEL IoT 4.0 Certification (Advanced Industrial IoT)
* Deloitte Enterprise-Grade Software Development Practice Certification
* Smart India Hackathon Finalist
    `;
    
    const blob = new Blob([resumeText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'S_Atkshara_Resume.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#140c0b]/80 backdrop-blur-md animate-fadeIn text-left">
      <div className="bg-[#FAF8F5] text-inverse-on-surface rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden shadow-2xl border border-outline-variant/20 flex flex-col animate-scaleIn">
        
        {/* Modal Header */}
        <div className="px-8 py-5 border-b border-outline-variant/10 flex justify-between items-center bg-[#2F221E] text-white">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-primary" />
            <span className="font-headline-sm text-lg font-serif">Curriculum Vitae</span>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={handleDownload}
              className="px-4 py-2 bg-primary text-on-primary font-label-caps text-[10px] font-semibold tracking-widest rounded-full hover:shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              DOWNLOAD PDF
            </button>
            <button 
              onClick={onClose}
              className="text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded-full transition-colors cursor-pointer"
              aria-label="Close resume"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-8 overflow-y-auto space-y-8 flex-1 font-sans">
          
          {/* Resume Header Section */}
          <div className="text-center sm:text-left border-b pb-6 space-y-3">
            <h2 className="font-display-lg text-4xl font-bold font-serif text-inverse-on-surface leading-none">
              S. Atkshara
            </h2>
            <p className="font-medium text-primary-container text-sm uppercase tracking-wider">
              AI &amp; Machine Learning Student | Full Stack Developer
            </p>
            
            {/* Contact Details Grid */}
            <div className="flex flex-wrap justify-center sm:justify-start gap-x-6 gap-y-2 pt-2 text-xs text-on-surface-variant font-light">
              <span className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-primary" />
                atkshara.s@example.com
              </span>
              <span className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-primary" />
                +91 98765 43210
              </span>
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-primary" />
                Chennai, India
              </span>
            </div>
          </div>

          {/* Education Block */}
          <div className="space-y-4">
            <h3 className="text-sm font-label-caps text-primary tracking-widest font-bold border-b pb-1 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-primary" />
              EDUCATION
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between items-start text-sm">
                <div>
                  <h4 className="font-bold text-inverse-on-surface">B.Tech in Artificial Intelligence &amp; Machine Learning</h4>
                  <p className="text-on-surface-variant text-xs font-light">Chennai Engineering Institution</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-inverse-on-surface">CGPA: 9.4 / 10</p>
                  <p className="text-on-surface-variant text-[10px] font-light">Expected 2025</p>
                </div>
              </div>
            </div>
          </div>

          {/* Experience Block */}
          <div className="space-y-4">
            <h3 className="text-sm font-label-caps text-primary tracking-widest font-bold border-b pb-1 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-primary" />
              PROFESSIONAL EXPERIENCE
            </h3>
            <div className="space-y-4">
              <div className="text-sm">
                <div className="flex justify-between items-start">
                  <h4 className="font-bold text-inverse-on-surface">IoT Research Intern</h4>
                  <span className="text-on-surface-variant text-xs font-light">Winter 2023</span>
                </div>
                <ul className="list-disc pl-5 mt-2 space-y-1.5 text-xs text-on-surface-variant font-light leading-relaxed">
                  <li>Hands-on experience in sensor hardware configuration, telemetry validation, and stream ingestion networks.</li>
                  <li>Constructed real-time performance rendering charts tracking physical stress models.</li>
                  <li>Collaborated with research mentors to deliver a production-grade localized data pipeline.</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Highlighted projects info */}
          <div className="space-y-4">
            <h3 className="text-sm font-label-caps text-primary tracking-widest font-bold border-b pb-1 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-primary" />
              NOTABLE ACADEMIC PROJECTS
            </h3>
            <div className="grid sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-surface-container-low/5 rounded-xl border border-outline-variant/10 space-y-1.5">
                <h4 className="font-bold text-inverse-on-surface">VOLTIS (EV Platform)</h4>
                <p className="text-on-surface-variant leading-relaxed font-light">
                  A smart grid load-balancer ecosystem engineered using MERN Stack. Resolves station load anomalies under extreme concurrency.
                </p>
              </div>
              <div className="p-4 bg-surface-container-low/5 rounded-xl border border-outline-variant/10 space-y-1.5">
                <h4 className="font-bold text-inverse-on-surface">ARKALEGAL (Legal Blockchain)</h4>
                <p className="text-on-surface-variant leading-relaxed font-light">
                  Tamper-proof file vault utilizing IPFS and Solidity smart contracts. Guarantees attorney-client privilege hashes immutability.
                </p>
              </div>
            </div>
          </div>

          {/* Academic Honors */}
          <div className="space-y-4">
            <h3 className="text-sm font-label-caps text-primary tracking-widest font-bold border-b pb-1 flex items-center gap-2">
              <Award className="w-4 h-4 text-primary" />
              ACCOMPLISHMENTS &amp; CERTIFICATIONS
            </h3>
            <ul className="list-disc pl-5 text-xs text-on-surface-variant font-light space-y-1.5 leading-relaxed">
              <li><strong>NPTEL IoT 4.0:</strong> Certified with Advanced standing in Industrial IoT systems.</li>
              <li><strong>Deloitte Certificate:</strong> Completed Enterprise Software Engineering virtual program.</li>
              <li><strong>Smart India Hackathon:</strong> Developed intelligent sensor models for local microgrid logistics.</li>
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
}
