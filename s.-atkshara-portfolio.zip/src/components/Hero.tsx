import React from 'react';
import { ArrowRight, Download } from 'lucide-react';

interface HeroProps {
  onResumeClick: () => void;
  onViewProjectsClick: () => void;
}

export default function Hero({ onResumeClick, onViewProjectsClick }: HeroProps) {
  return (
    <section 
      id="home" 
      className="relative min-h-screen flex items-center pt-24 overflow-hidden bg-[#1C1412] hero-gradient"
    >
      {/* Background radial blurs */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-1/4 -left-1/4 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 -right-1/4 w-[600px] h-[600px] bg-tertiary/10 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-container-max mx-auto px-gutter relative z-10 w-full">
        <div className="grid md:grid-cols-2 gap-12 items-center py-12 md:py-24">
          
          {/* Left Text Content */}
          <div className="space-y-8 text-left animate-slideUp">
            <div className="space-y-2">
              <p className="font-label-caps text-label-caps tracking-[0.3em] text-tertiary">
                PORTFOLIO '24
              </p>
              <h1 className="font-display-lg text-display-lg-mobile md:text-display-lg leading-tight text-on-surface">
                Hi, I'm <span className="text-primary hover:opacity-90 transition-opacity">S. Atkshara</span>
              </h1>
            </div>
            
            <p className="font-headline-sm text-headline-sm text-on-surface-variant max-w-lg leading-relaxed">
              AI &amp; Machine Learning Undergraduate | Full Stack Developer | AI Enthusiast
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <button 
                onClick={onViewProjectsClick}
                className="group px-8 py-4 bg-primary text-on-primary font-label-caps text-label-caps rounded-full hover:shadow-[0_20px_40px_rgba(255,179,180,0.25)] hover:scale-[1.02] active:scale-95 transition-all duration-300 flex items-center gap-2 cursor-pointer"
              >
                VIEW PROJECTS
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              
              <button 
                onClick={onResumeClick}
                className="group px-8 py-4 border border-tertiary text-tertiary font-label-caps text-label-caps rounded-full hover:bg-tertiary/10 hover:scale-[1.02] active:scale-95 transition-all duration-300 flex items-center gap-2 cursor-pointer"
              >
                DOWNLOAD RESUME
                <Download className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
              </button>
            </div>
          </div>

          {/* Right Visual Image Column */}
          <div className="relative group w-full max-w-md mx-auto md:max-w-none">
            <div className="absolute -inset-1.5 bg-gradient-to-r from-primary to-tertiary rounded-2xl blur opacity-20 group-hover:opacity-35 transition duration-1000" />
            <div className="relative overflow-hidden rounded-xl aspect-[4/5] glass border border-outline-variant/20 shadow-2xl">
              <img 
                className="w-full h-full object-cover grayscale opacity-80 group-hover:grayscale-0 group-hover:scale-102 transition-all duration-700 select-none pointer-events-none" 
                alt="High-tech obsidian texture with intricate flowing amber light trails reflecting cherry red highlights, abstract machine learning art" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuArlwHtwT71DoDh4_np5ZLUAGrkEg5ldGeamaYA1rZriIsOmXPHPC2cV4uk9Ip7DqvzDDegx8O5CO9rP2ZIH4uTI8aq0FBzgF6YRk0WPVSAT6HnDmhz_7gulav5rtj2ne7yqpeUVdHRA5lXgVpdZY7-Q_2fHh1duQ-SQVTxoK809DT0E7EAv9KfSr-IlR3erxROqhPxfGJ73Y4hEwEMvaGKcYTyUkFPOkUjp9EKAMF6FGWroqFRa22Y00b_gNdggkCAXO4W43XImr_V"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-40" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
