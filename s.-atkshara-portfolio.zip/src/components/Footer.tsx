import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-surface-container-lowest border-t border-primary/20 w-full py-16 md:py-24 text-left">
      <div className="flex flex-col md:flex-row justify-between items-start px-gutter max-w-container-max mx-auto gap-12 md:gap-6">
        
        {/* Brand & Rights */}
        <div className="space-y-3">
          <span className="font-headline-sm text-headline-sm text-primary font-semibold font-serif tracking-tight">
            S. Atkshara
          </span>
          <p className="font-body-md text-on-surface-variant text-sm mt-2 font-light">
            © 2024 S. Atkshara • Crafted with AI &amp; Precision
          </p>
        </div>

        {/* Resources & Social Handles links */}
        <div className="flex gap-12 lg:gap-20">
          
          {/* Socials Col */}
          <div className="flex flex-col gap-3">
            <p className="font-label-caps text-tertiary text-[10px] font-bold tracking-widest uppercase">
              SOCIALS
            </p>
            <a 
              href="https://linkedin.com" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="font-body-md text-on-surface-variant hover:text-primary text-sm transition-all underline decoration-tertiary/30 hover:decoration-primary/50 underline-offset-4"
            >
              LinkedIn
            </a>
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="font-body-md text-on-surface-variant hover:text-primary text-sm transition-all underline decoration-tertiary/30 hover:decoration-primary/50 underline-offset-4"
            >
              GitHub
            </a>
          </div>

          {/* Resources Col */}
          <div className="flex flex-col gap-3">
            <p className="font-label-caps text-tertiary text-[10px] font-bold tracking-widest uppercase">
              RESOURCES
            </p>
            <a 
              href="https://researchgate.net" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="font-body-md text-on-surface-variant hover:text-primary text-sm transition-all underline decoration-tertiary/30 hover:decoration-primary/50 underline-offset-4"
            >
              ResearchGate
            </a>
            <a 
              href="#contact" 
              className="font-body-md text-on-surface-variant hover:text-primary text-sm transition-all underline decoration-tertiary/30 hover:decoration-primary/50 underline-offset-4"
            >
              Contact
            </a>
          </div>

        </div>

      </div>
    </footer>
  );
}
