import React, { useState } from 'react';
import { Eye, Github, X, CheckCircle2, Calendar, User, Layers } from 'lucide-react';
import { PROJECTS } from '../data';
import { Project } from '../types';

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <section 
      id="projects" 
      className="py-section-gap bg-[#F8F5F2] text-inverse-on-surface"
    >
      <div className="max-w-container-max mx-auto px-gutter">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-4">
          <div className="text-left">
            <p className="font-label-caps text-primary tracking-widest mb-4">SELECTED WORKS</p>
            <h2 className="font-display-lg text-display-lg-mobile text-inverse-on-surface font-serif">
              Featured Projects
            </h2>
          </div>
          <div className="w-full md:w-auto text-left md:text-right border-t md:border-t-0 pt-4 md:pt-0">
            <div className="h-[1px] w-full md:w-48 bg-primary/30 mb-2 hidden md:block ml-auto" />
            <p className="font-body-md italic text-on-surface-variant text-sm">
              Defining the future of digital ecosystems.
            </p>
          </div>
        </div>

        {/* Project Cards Grid */}
        <div className="grid md:grid-cols-2 gap-12">
          {PROJECTS.map((project) => {
            const isBlockchain = project.tag === 'BLOCKCHAIN';
            return (
              <div 
                key={project.id}
                className="group relative bg-white/60 backdrop-blur-md rounded-2xl overflow-hidden border border-outline-variant/10 hover:shadow-2xl hover:border-primary/20 transition-all duration-500 flex flex-col justify-between"
              >
                {/* Visual Image Container */}
                <div className="aspect-video overflow-hidden relative">
                  <div className={`absolute inset-0 mix-blend-overlay group-hover:bg-transparent transition-all duration-500 z-10 ${
                    isBlockchain ? 'bg-tertiary/20' : 'bg-primary/20'
                  }`} />
                  <img 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 select-none pointer-events-none" 
                    alt={project.title}
                    src={project.imageUrl}
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-4 py-1.5 rounded-full text-[10px] font-bold tracking-widest text-[#191210] uppercase shadow-sm z-20">
                    {project.tag}
                  </div>
                </div>

                {/* Content Box */}
                <div className="p-8 lg:p-10 space-y-6 flex-grow flex flex-col justify-between text-left">
                  <div className="space-y-4">
                    <h3 className="font-headline-md text-inverse-on-surface font-serif">{project.title}</h3>
                    <p className="font-body-md text-on-surface-variant line-clamp-3 text-sm leading-relaxed">
                      {project.description}
                    </p>
                    
                    {/* Technology Labels */}
                    <div className="flex flex-wrap gap-2 pt-2">
                      {project.technologies.map((tech) => (
                        <span 
                          key={tech} 
                          className="px-3 py-1 bg-surface-container-low/5 text-inverse-on-surface text-xs font-semibold rounded border border-outline-variant/5"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions Link Row */}
                  <div className="flex gap-6 pt-4 border-t border-outline-variant/5">
                    <button 
                      onClick={() => setSelectedProject(project)}
                      className="flex items-center gap-2 text-primary font-bold hover:text-primary-container transition-colors duration-200 cursor-pointer text-sm"
                    >
                      <Eye className="w-4 h-4" /> 
                      VIEW DETAILS
                    </button>
                    
                    <a 
                      href={project.githubLink}
                      className="flex items-center gap-2 text-inverse-on-surface font-bold hover:text-primary transition-colors duration-200 cursor-pointer text-sm"
                    >
                      <Github className="w-4 h-4" /> 
                      GITHUB
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* High-fidelity Detail Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#140c0b]/75 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#FAF8F5] text-inverse-on-surface rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto shadow-2xl border border-outline-variant/20 relative animate-scaleIn">
            
            {/* Header banner */}
            <div className="relative h-48 sm:h-56 overflow-hidden">
              <img 
                className="w-full h-full object-cover" 
                alt={selectedProject.title} 
                src={selectedProject.imageUrl}
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#FAF8F5] via-[#FAF8F5]/30 to-transparent" />
              <button 
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 bg-white/90 hover:bg-white text-inverse-on-surface p-2 rounded-full shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="p-8 space-y-6 text-left">
              <div>
                <span className="px-3 py-1 bg-primary/10 text-primary text-xs font-bold rounded-full tracking-widest uppercase">
                  {selectedProject.tag}
                </span>
                <h3 className="font-headline-md text-3xl font-serif text-inverse-on-surface mt-2">
                  {selectedProject.title}
                </h3>
              </div>

              {/* Roles & Timeline Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-4 px-5 bg-surface-container-low/5 rounded-xl border border-outline-variant/10 text-sm">
                <div className="flex items-center gap-2.5">
                  <User className="w-4 h-4 text-primary shrink-0" />
                  <div>
                    <p className="text-xs text-on-surface-variant font-semibold">MY ROLE</p>
                    <p className="font-medium text-inverse-on-surface leading-tight text-xs">{selectedProject.details.role}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2.5">
                  <Calendar className="w-4 h-4 text-tertiary shrink-0" />
                  <div>
                    <p className="text-xs text-on-surface-variant font-semibold">TIMELINE</p>
                    <p className="font-medium text-inverse-on-surface leading-tight text-xs">{selectedProject.details.timeline}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <Layers className="w-4 h-4 text-secondary shrink-0" />
                  <div>
                    <p className="text-xs text-on-surface-variant font-semibold">STACK</p>
                    <p className="font-medium text-inverse-on-surface leading-tight text-xs">{selectedProject.technologies.slice(0, 3).join(', ')}</p>
                  </div>
                </div>
              </div>

              {/* Description & Features */}
              <div className="space-y-4">
                <h4 className="font-semibold text-inverse-on-surface border-b pb-1">Project Overview</h4>
                <p className="text-sm text-on-surface-variant leading-relaxed">
                  {selectedProject.details.overview}
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-inverse-on-surface border-b pb-1">Key Architectures &amp; Achievements</h4>
                <ul className="space-y-2.5">
                  {selectedProject.details.keyFeatures.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-sm text-on-surface-variant">
                      <CheckCircle2 className="w-4.5 h-4.5 text-primary shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Footer Buttons */}
              <div className="flex gap-4 pt-4 justify-end border-t border-outline-variant/10">
                <button 
                  onClick={() => setSelectedProject(null)}
                  className="px-5 py-2.5 border border-outline-variant/20 hover:bg-surface-container-low/5 rounded-lg text-sm cursor-pointer"
                >
                  Close
                </button>
                <a 
                  href={selectedProject.githubLink}
                  className="px-5 py-2.5 bg-[#191210] hover:bg-primary text-white hover:text-[#191210] rounded-lg text-sm font-semibold transition-all duration-200 cursor-pointer inline-flex items-center gap-2"
                >
                  <Github className="w-4 h-4" />
                  View Repository
                </a>
              </div>

            </div>

          </div>
        </div>
      )}

    </section>
  );
}
