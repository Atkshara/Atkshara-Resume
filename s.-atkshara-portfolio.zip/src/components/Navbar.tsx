import React, { useState, useEffect } from 'react';
import { Menu, X, FileText } from 'lucide-react';

interface NavbarProps {
  onResumeClick: () => void;
}

export default function Navbar({ onResumeClick }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [scrollProgress, setScrollProgress] = useState(0);

  const navLinks = [
    { label: 'Home', id: 'home' },
    { label: 'Research', id: 'about' },
    { label: 'Skills', id: 'skills' },
    { label: 'Portfolio', id: 'projects' },
    { label: 'Contact', id: 'contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      // Calculate scroll progress
      const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrolled = height > 0 ? (winScroll / height) * 100 : 0;
      setScrollProgress(scrolled);

      // Determine active section
      const sections = navLinks.map(link => document.getElementById(link.id));
      let currentSection = 'home';
      
      sections.forEach(section => {
        if (section) {
          const rect = section.getBoundingClientRect();
          // If the top of the section is near the top of the viewport
          if (rect.top <= 160) {
            currentSection = section.id;
          }
        }
      });
      setActiveSection(currentSection);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setIsOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Scroll indicator */}
      <div 
        id="progress-bar" 
        className="scroll-indicator" 
        style={{ width: `${scrollProgress}%` }}
      />

      <nav className="fixed top-0 w-full z-50 bg-surface/80 backdrop-blur-xl border-b border-outline-variant/10 shadow-sm">
        <div className="flex justify-between items-center px-gutter py-4 max-w-container-max mx-auto">
          <span 
            className="font-headline-sm text-headline-sm font-semibold text-primary cursor-pointer tracking-tight"
            onClick={() => scrollToSection('home')}
          >
            S. Atkshara
          </span>

          {/* Desktop Navigation */}
          <div className="hidden md:flex gap-8 items-center">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className={`font-label-caps text-label-caps tracking-widest pb-1 transition-colors duration-300 border-b-2 cursor-pointer ${
                  activeSection === link.id
                    ? 'text-primary border-primary'
                    : 'text-on-surface-variant border-transparent hover:text-primary'
                }`}
              >
                {link.label}
              </button>
            ))}
            <button 
              onClick={onResumeClick}
              className="ml-4 px-6 py-2 bg-primary-container text-on-primary-container font-label-caps text-label-caps rounded-full hover:bg-primary-container/90 active:scale-95 transition-all duration-200 shadow-sm cursor-pointer inline-flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" />
              Resume
            </button>
          </div>

          {/* Mobile Navigation Toggle */}
          <button 
            className="md:hidden text-primary cursor-pointer p-1"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Panel */}
        {isOpen && (
          <div className="md:hidden bg-[#1E1614] border-b border-outline-variant/10 px-gutter py-6 flex flex-col gap-4 animate-fadeIn">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className={`font-label-caps text-label-caps tracking-widest py-2 text-left transition-colors duration-200 ${
                  activeSection === link.id ? 'text-primary' : 'text-on-surface-variant'
                }`}
              >
                {link.label}
              </button>
            ))}
            <button 
              onClick={() => {
                setIsOpen(false);
                onResumeClick();
              }}
              className="mt-2 w-full py-3 bg-primary-container text-on-primary-container font-label-caps text-label-caps rounded-full text-center hover:bg-primary-container/90 transition-colors duration-200 flex items-center justify-center gap-2"
            >
              <FileText className="w-4 h-4" />
              Resume
            </button>
          </div>
        )}
      </nav>
    </>
  );
}
