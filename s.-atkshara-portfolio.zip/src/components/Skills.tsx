import React from 'react';
import { Terminal, Globe, Brain, Database, Wrench } from 'lucide-react';
import { SKILL_CATEGORIES } from '../data';

const iconMap: Record<string, React.ComponentType<any>> = {
  terminal: Terminal,
  language: Globe,
  psychology: Brain,
  database: Database,
  construction: Wrench,
};

export default function Skills() {
  return (
    <section 
      id="skills" 
      className="py-section-gap bg-[#2F221E] relative overflow-hidden"
    >
      {/* Visual Ambient Blur */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-container-max mx-auto px-gutter relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-20">
          <p className="font-label-caps text-primary tracking-widest mb-4">CAPABILITIES</p>
          <h2 className="font-display-lg text-display-lg-mobile text-on-surface font-serif">
            Technical Arsenal
          </h2>
          <div className="sandal-divider w-32 mx-auto mt-6" />
        </div>

        {/* Skill Category Cards Grid */}
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {SKILL_CATEGORIES.map((category, index) => {
            const IconComponent = iconMap[category.iconName] || Terminal;
            const isEven = index % 2 === 0;

            return (
              <div 
                key={category.title}
                className="glass p-8 rounded-[18px] hover:-translate-y-2 hover:shadow-lg hover:border-primary/20 transition-all duration-300 flex flex-col justify-between group cursor-default"
              >
                <div>
                  {/* Category Icon */}
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 transition-colors duration-300 ${
                    isEven 
                      ? 'bg-tertiary/10 text-tertiary group-hover:bg-tertiary group-hover:text-background' 
                      : 'bg-primary/10 text-primary group-hover:bg-primary group-hover:text-background'
                  }`}>
                    <IconComponent className="w-6 h-6" />
                  </div>

                  {/* Category Title */}
                  <h3 className="font-headline-sm mb-4 text-on-surface text-lg font-semibold tracking-tight">
                    {category.title}
                  </h3>
                  
                  {/* Skill list */}
                  <ul className="space-y-3 font-body-md text-on-surface-variant text-sm">
                    {category.skills.map((skill) => (
                      <li key={skill} className="flex items-center gap-2 group-hover:text-on-surface transition-colors duration-200">
                        <span className={`w-1.5 h-1.5 rounded-full transition-transform duration-300 group-hover:scale-125 ${
                          isEven ? 'bg-tertiary' : 'bg-primary'
                        }`} />
                        {skill}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
